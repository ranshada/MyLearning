package com.ranjith.SpringLearning28Min;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearning28MinApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringLearning28MinApplication.class, args);
	}

}
