package com.ranjith.SpringLearning28Min;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearning28MinApplicationTests {

	@Test
	void contextLoads() {
	}

}
